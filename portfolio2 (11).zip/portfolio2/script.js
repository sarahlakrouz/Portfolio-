let darkMode = false;

function changeDarkMode(){//fonction permettant d'actionner tous les changements
  if(darkMode){
    //light mode
    darkMode=false; //on met en light mode
    document.documentElement.style.setProperty("--text-color","black",);//on accède à la méthode property de document documentElement style
    document.documentElement.style.setProperty("--background-color","#efe7e5");//la couleur du background 
    document.getElementById("dark-light-mode" ).innerHTML="Dark Mode";//on écrit dark mode
}else{
  //dark mode
  darkMode=true; //on met en dark mode
    document.documentElement.style.setProperty("--text-color","white");//on accède à la méthode property de document documentElement style
    document.documentElement.style.setProperty("--background-color","black");//la couleur du background 
    document.getElementById("dark-light-mode" ).innerHTML="Light Mode";//on écrit light mode
}}

function showAlert(event) {
  event.preventDefault(); // Empêche le formulaire de se soumettre normalement

  // Récupère les valeurs du formulaire
  const nom = document.getElementById('nom').value;
  const email = document.getElementById('email').value;
  const message = document.getElementById('message').value;

  // Affiche une alerte avec les valeurs du formulaire
  alert(`Nom: ${nom}\nE-mail: ${email}\nMessage: ${message}`);
}